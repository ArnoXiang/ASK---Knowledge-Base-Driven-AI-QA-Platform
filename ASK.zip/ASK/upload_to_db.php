
<?php

//连接phpmyadmin和db
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "root";
    $conn = mysqli_connect($dbhost,$dbuser,$dbpass);

    if(!$conn)
    {
        echo "服务器连接失败：".mysqli_connect_error();
    }

    mysqli_select_db($conn,"ask");
    mysqli_query($conn,"set names 'utf8'");


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $slice_embeddings = $_POST['slice_embeddings'];  
        $file_name = $_POST['file_name']; 

        $psword =$conn->real_escape_string($_POST['psword']);
    } else {
        echo "请求方法不允许";
    }


//$filetexts和$filename，传到这个页面，切片，装入字典，将filename/original text/vector存入数据库
foreach ($slice_embeddings as $slice) {
    $filetext = $conn->real_escape_string($slice[0]);
    $vector = is_null($slice[1]) ? 'NULL' : "'" . json_encode($slice[1]) . "'";
    
    $sql = "INSERT INTO slice (file_name, original_text, vector)
            VALUES ('$file_name', '$filetext', $vector)";

    if ($conn->query($sql) === FALSE) {
        echo "Error inserting data into database: " . $sql . "<br>" . $conn->error . "\n";
    }
}

// 找首尾项的id
$beginning_id = null;
$end_id = null;

if (!empty($slice_embeddings)) {
    $first_slice = reset($slice_embeddings);
    $filetext = $conn->real_escape_string($first_slice[0]);
    $sql = "SELECT id FROM slice WHERE original_text = '$filetext'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $beginning_id = $row['id'];
    }

    $last_slice = end($slice_embeddings);
    $filetext = $conn->real_escape_string($last_slice[0]);
    $sql = "SELECT id FROM slice WHERE original_text = '$filetext'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $end_id = $row['id'];
    }
}

$id_range = $beginning_id . "a" . $end_id;

    //生成hash值,返回给用户

    $salt = bin2hex(random_bytes(16));//https://m.php.cn/faq/573599.html

    $hashedPassword = password_hash($id_range.$salt, PASSWORD_DEFAULT);

    $sql = "INSERT INTO files (id_range, psword, salt, file_name) VALUES ('$id_range', '$hashedPassword', '$salt', '$file_name')";

    if(mysqli_query($conn, $sql)){

        echo "插入成功，您的文件".$file_name."随机值为".$hashedPassword."<br>请妥善保存，作为访问该文件的唯一码" ;

    } 
        
    else{

        echo "插入失败，请稍后再试".mysqli_error($conn);

    }

    $conn->close();
?>


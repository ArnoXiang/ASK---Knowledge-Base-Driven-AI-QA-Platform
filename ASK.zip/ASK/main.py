from typing import Union, List, Dict
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from zhipuai import ZhipuAI
import time
import logging
import time
import re
from langchain_openai import ChatOpenAI
from langchain.prompts import (
    ChatPromptTemplate,
    MessagesPlaceholder,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from docx import Document
import os
import PyPDF2

# 初始化FastAPI应用
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 或者指定允许的来源，例如 ["http://localhost", "http://127.0.0.1"]
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)


# 初始化日志记录
logging.basicConfig(level=logging.INFO)

# 初始化质普清言API客户端
client = ZhipuAI(api_key="d8e950d6d3153a69432fc57226e11bd8.S3Osv7NSS9d0kGsw")  # 填写您自己的APIKey

# 全局字典存储会话状态
conversations: Dict[str, ConversationBufferMemory] = {}

# 需要从前端传递到后端的变量、类名在此定义
class UserRequest(BaseModel): 
    question: str
    knowledge: str
    file_code: str

class FileProcess(BaseModel): 
    file_type: str
    file_name: str

@app.get("/")
def read_root():
    return {"Hello": "World"}

@app.post("/dialog/")
def dialog(request: UserRequest):
    file_code = request.file_code
    # 如果会话不存在则创建新的记忆实例
    if file_code not in conversations:
        memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
        conversations[file_code] = memory
    else:
        memory = conversations[file_code]
    
    # 创建LLM实例
    llm = ChatOpenAI(
        temperature=0.95,
        model="glm-4",
        openai_api_key="d8e950d6d3153a69432fc57226e11bd8.S3Osv7NSS9d0kGsw",
        openai_api_base="https://open.bigmodel.cn/api/paas/v4/"
    )
    
    # 创建prompt模板
    prompt = ChatPromptTemplate(
        messages=[
            SystemMessagePromptTemplate.from_template(
                f"你是一个优秀的助手，请根据已有信息回答用户提出的问题。已有信息：{request.knowledge}"
            ),
            MessagesPlaceholder(variable_name="chat_history"),
            HumanMessagePromptTemplate.from_template("{question}")
        ]
    )
    
    # 创建对话链
    conversation = LLMChain(
        llm=llm,
        prompt=prompt,
        verbose=True,
        memory=memory
    )
    
    # 调用对话链获取响应
    response = conversation.invoke({"question": request.question})
    print(f"当前对话记忆：{memory}")
    return {"text": response['text'], "file_code": file_code}



# 以下定义函数均为读取文件、切片、向量化所需
def read_file(file_name, file_type):
    try:
        if file_type.lower() == 'txt':  # 检查文件类型是否为文本文件
            with open(file_name, 'r', encoding='utf-8') as file:
                text = file.read()
                return text
        elif file_type.lower() == 'docx':  # 检查文件类型是否为Word文档
            doc = Document(file_name)  # 使用python-docx加载Word文档
            text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])  # 提取所有段落的文本
            return text
        elif file_type.lower() == 'pdf':  # 检查文件类型是否为PDF
            with open(file_name, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                page_count = len(pdf_reader.pages)
                # print(page_count)

                # 提取文本
                for page in pdf_reader.pages:
                    text = page.extract_text()
                    return text
        else:
            print("不支持的文件类型。")
            return ""
    except Exception as e:
        print(f"读取文件时出错：{e}")
        return ""

def detect_language(text):
    # 检查是否包含中文字符
    if re.search('[\u4e00-\u9fff]', text):
        return 'zh'
    else:
        return 'en'

def is_valid_end_punctuation(text, index):
    # 检查英文句号是否为完整断句而不是其他用途
    if text[index] == '.':
        if index > 0 and text[index - 1].isdigit() and (index + 1 < len(text) and text[index + 1].isdigit()):
            return False  # 这是小数点的情况
        if index + 1 < len(text) and text[index + 1].isspace():
            return True  # 句号后有空白字符
        if index + 1 == len(text):
            return True  # 句号在文本末尾
    return False

def slice_text(text):
    language = detect_language(text)
    #此处均以字符为单位，因此数量进行了调整。
    if language == 'en':
        min_slice_size = 600
        max_slice_size = 700
    else:
        min_slice_size = 400
        max_slice_size = 450

    slices = []
    start = 0
    text_length = len(text)
    
    while start < text_length:
        end = start + min_slice_size
        if end >= text_length:
            slices.append(text[start:])
            break
        
        slice_text = text[start:end]

        # 查找中英文句号
        match = None
        for i in range(min_slice_size, min_slice_size + (max_slice_size - min_slice_size)):
            if start + i >= text_length:
                break
            if text[start + i] in '。':
                match = start + i + 1
                break
            if text[start + i] == '.' and is_valid_end_punctuation(text, start + i):
                match = start + i + 1
                break

        if match:
            end = match
        else:
            # 查找回车符
            match = re.search(r'[\r\n]', text[start:end+max_slice_size-min_slice_size])
            if match:
                end = start + match.end()
            else:
                # 强行在最大切片范围处切分，确保英文切片在单词边界处完成
                end = start + max_slice_size
                if language == 'en':
                    while end > start and not text[end-1].isspace():
                        end -= 1

        if not text[start:end].isspace(): # 检查切片是否全都是空格，如是则跳过
            slices.append(text[start:end])
        start = end
    
    return slices
 
@app.post('/file/')
# 函数参数即为前端传递过来的文件/字符串
# 1.接收前端上传的文件
async def get_user(
        #fileb: bytes = File(...),            # 把文件对象转为bytes类型，这种类型的文件无法保存
        file: UploadFile = File(...)   # UploadFile转为文件对象，可以保存文件到本地
        #notes: str = Form(...)              # 获取普通键值对
):
    # 2.保存前端上传的文件至本地服务器
    # 2.1 读取前端上传到的fileb文件
    contents = await file.read()
    # print(contents)
    # print(file.filename)
    # 2.2 打开新文件
    # 第一个参数 文件存储路径+文件名称，存储路径目录需要提前创建好，如果没有指定，则默认会保存在本文件的同级目录下
    # 第二个参数 wb，表示以二进制格式打开文件，用于只写
    with open("D:\\phpstudy_pro\\WWW\\ask\\files\\"+file.filename, "wb") as f:
        # 2.3 将获取的fileb文件内容，写入到新文件中
        f.write(contents) 
    # 启动服务后，会在本地FastAPI服务器的files目录下生成 前端上传的文件
 
    '''return ( {
        #'file_size': len(fileb),
        'file_name': file.filename,
        #'notes': notes,
        'file_content_type': file.content_type
    })'''



    file_name = "D:\\phpstudy_pro\\WWW\\ask\\files\\"+file.filename #改成自己的目录
    file_type = file.filename.split(".")[-1]

    file_text = read_file(file_name, file_type) # 读取文件操作
    slices = slice_text(file_text) # 切片操作
        
    slice_embeddings =[]
    for n, slice in enumerate(slices):
        slice_response = client.embeddings.create(
            model="embedding-2",
            input=slice,
            )
        slice_embedding = slice_response.data[0].embedding
        logging.info(f"slice {n+1} embedding: {slice_embedding}") 
        slice_embeddings.append([slice, slice_embedding])
        time.sleep(1)
    return slice_embeddings # 最终返回所有切片和其向量的list


@app.post("/get-sentence-embedding/")
async def get_sentence_embedding(request: UserRequest):
    try:
        logging.info(f"Received sentence embedding request: {request}")
        
        if not request.question:
            raise HTTPException(status_code=422, detail="Question field is required")
        
        text = request.question
        
        response = client.embeddings.create(
            model="embedding-2",
            input=text,
        )
        embedding = response.data[0].embedding
        
        logging.info(f"Sentence embedding generated successfully")
        
        return {"embedding": embedding}
    except Exception as e:
        logging.error(f"Error occurred while getting sentence embedding: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)

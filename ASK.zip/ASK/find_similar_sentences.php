<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_embedding = $_POST['input_embedding'];
    $file_code = $_POST['file_code'];
    $num_similar = isset($_POST['num_similar']) ? intval($_POST['num_similar']) : 2; // 默认为2，可通过参数调整

    // 连接到 MySQL 数据库
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "ask"; // 修改为您的数据库名称

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // 获取文件的id范围
    $sql = "SELECT id_range FROM files WHERE psword='$file_code'";
    $result = $conn->query($sql);
    if (!$result || $result->num_rows == 0) {
        die("File not found or error occurred while querying database: " . $conn->error);
    }
    $row = $result->fetch_assoc();
    list($start_id, $end_id) = explode('a', $row['id_range']);

    // 查询 slice 表, 计算输入句子与每个句子的余弦相似度
    $sql = "SELECT id, file_name, original_text, vector, date FROM slice WHERE id BETWEEN $start_id AND $end_id";
    $result = $conn->query($sql);

    if (!$result) {
        die("Error occurred while querying database: " . $conn->error);
    }

    $similar_records = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $vector = json_decode($row['vector'], true);

            // 计算输入句子与内容的余弦相似度
            $dot_product = 0;
            $input_norm = 0;
            $vector_norm = 0;
            for ($i = 0; $i < count($input_embedding); $i++) {
                $dot_product += $input_embedding[$i] * $vector[$i];
                $input_norm += $input_embedding[$i] * $input_embedding[$i];
                $vector_norm += $vector[$i] * $vector[$i];
            }
            $input_norm = sqrt($input_norm);
            $vector_norm = sqrt($vector_norm);
            $similarity = $dot_product / ($input_norm * $vector_norm);

            $row['similarity'] = $similarity;
            $similar_records[] = $row;
        }
    }

    // 按相似度降序排序
    usort($similar_records, function($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
    });

    // 选择前 $num_similar 个记录
    $similar_records = array_slice($similar_records, 0, $num_similar);

    // 组合文本
    $combined_text = implode("\n", array_map(function($record) {
        return $record['original_text'];
    }, $similar_records));

    $conn->close();

    // 构造返回结果
    $result = [
        'most_similar_record' => [
            'id' => $similar_records[0]['id'],
            'file_name' => $similar_records[0]['file_name'],
            'original_text' => $combined_text,
            'vector' => $similar_records[0]['vector'],
            'date' => $similar_records[0]['date']
        ]
    ];

    // 将结果返回给前端
    echo json_encode($result);
}
?>
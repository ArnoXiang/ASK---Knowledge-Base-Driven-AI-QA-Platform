
<?php

//连接phpmyadmin和db
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "root";
    $conn = mysqli_connect($dbhost,$dbuser,$dbpass);

    if(!$conn)
    {
        echo "服务器连接失败：".mysqli_connect_error();
    }

    mysqli_select_db($conn,"ask");
    mysqli_query($conn,"set names 'utf8'");


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $psword =$conn->real_escape_string($_POST['psword']);
    } else {
        echo "请求方法不允许";
    }

$sql = "SELECT file_name FROM files WHERE psword = '$psword'";
$result =$conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        // 输出数据
        while($row =$result->fetch_assoc()) {
            echo $row["file_name"];
        }
    } else {
        echo "没有找到对应的文件名。";
    }
} else {
    echo "查询失败: " . $conn->error; // 添加错误信息
}

    $conn->close();
?>


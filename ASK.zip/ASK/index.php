<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>ASK</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://cdn.bootcdn.net/ajax/libs/marked/13.0.0/marked.min.js"></script>
    <link rel="icon" href="data:;base64,iVBORw0KGgo=">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            height: 100%;
        }
        .content {
            min-height: 100%;
            margin-bottom: -50px;
        }
        #num-similar-input {
            width: 50px;
            margin-left: 10px;
            margin-right: 10px;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        section {
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        #knowledge-input {
            width: 500px;
            height: 200px;
            padding: 10px;
            margin-right: 10px;
        }
        #upload-section input {
            margin-top: 10px;
        }
        #qa-section {
            position: relative;
            display: flex;
            flex-direction: column;
            
        }
        #question-input {
            width: 200px;
            padding: 10px;
            margin-right: 10px;
        }
        #psword-input {
            width: 200px;
            padding: 10px;
            margin-right: 10px;
        }
        #submit-question {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        #submit-psword {
            padding: 10px 20px;
            margin-right: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        #upload-knowledge, #copy {
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 120px;
            margin-top: 10px; /* 添加这个来保持距离 */
        }
        
        .chat-container {
            flex: 1;
            overflow-y: auto;
            padding-bottom: 100px; /* 留出输入框的空间 */
        }
        
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
            height: 50px;
            z-index: 1000; /* 确保页脚在其他内容之上 */
        }
        .nav-pills .nav-link.active, .nav-pills .show > .nav-link {
            color: #f4f4f4;
            background-color: #333;
        }
        .nav-pills .nav-link {
            color: #333;
        }
        .nav-pills .nav-link {
            font-size: 16px; /* 设置导航栏按钮的字体大小 */
        }
        section h2 {
            font-size: 20px; /* 设置内容区域标题的字体大小 */
        }
        /* 添加头像样式 */
        .avatar-user {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-left: 78%;
        }
        .avatar-bot {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .chat-bubble-container {
            display: flex;
            justify-content: flex-end; /* 确保容器内元素向右对齐 */
            margin: 10px 0;
        }
        .user-bubble-container {
            justify-content: flex-end;
            flex-direction: row-reverse; /* 用户头像显示在右侧 */
        }
        .bot-bubble-container {
            justify-content: flex-start;
        }
        .chat-bubble {
            max-width: 75%;
            padding: 10px;
            border-radius: 10px;
            position: relative;
            word-wrap: break-word; /* 防止长单词溢出 */
            background-color: #ffffff; /* 气泡背景色 */
        }
        .user-bubble {
            background-color: #333333; /* 根据网页主题色进行调整 */
            color: white;
            margin-left:-26%;
            align-self: flex-end; /* 将用户气泡靠右显示 */
            left: 77%;
        }
        .bot-bubble {
            background-color: #f1f1f1;
            color: black;
            margin-right: 10px;
        }
       
        /* 让白色背景框根据内容自适应高度 */
        .chat-container {
            position: relative;
            overflow: hidden;
            padding-bottom: 50px; /* 为输入框预留空间 */
        }
        .chat-content {
            max-height: 70vh; /* 限制内容高度，以防止溢出 */
            overflow-y: auto; /* 添加滚动条以便查看长内容 */
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
        }
        .fixed-bottom {
            position: fixed;
            right: 0;
            bottom: 40px;
            left: 0;
            z-index: 1030;
        }
        #file-name {
            padding: 10px;      
            margin: 20px 0;          
            border: 1px solid #ddd;   
            font-family: Arial, sans-serif; 
            border-radius: 5px;    
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
            text-align: left;   
            width: 300px;  
        }

    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1 class="text-center">ASK——基于知识库的GPT问答网站</h1>
        </div>
    </header>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-3">
                <!-- 左侧导航栏 -->
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active" id="v-pills-upload-tab" data-toggle="pill" href="#v-pills-upload" role="tab" aria-controls="v-pills-upload" aria-selected="true">上传知识</a>
                    <a class="nav-link" id="v-pills-qa-tab" data-toggle="pill" href="#v-pills-qa" role="tab" aria-controls="v-pills-qa" aria-selected="false">连续问答</a>
                </div>
            </div>
            <div class="col-md-9">
                <!-- 标签页内容 -->
                <div class="tab-content" id="v-pills-tabContent">
                    <!-- 上传知识部分 -->
                    <div class="tab-pane fade show active" id="v-pills-upload" role="tabpanel" aria-labelledby="v-pills-upload-tab">
                        <section id="upload-section">
                            <h2>上传知识</h2> <br>
                            <!-- 使用Bootstrap的row和col来调整布局 -->
                            <div class="row">
                                <div class="col-md-2">
                                    <button id="upload-knowledge" class="btn btn-secondary btn-block">确认上传</button>
                                </div>
                                <div class="col-md-12 text-right mt-3">
                                    <input type="file" id="fileInput" class="form-control-file" accept=".docx,.txt,.pdf">
                                </div>
                                <div id="uploadMessage"></div>
                                
                                <div id="copypaste">
                                        <button id="copy">一键复制</button>
                                </div>
                            </div>
                        </section>
                    </div>
                   
<div class="tab-pane fade" id="v-pills-qa" role="tabpanel" aria-labelledby="v-pills-qa-tab">
    <section id="qa-section">
        <div class="row">
            <div class="col-md-12">
                <div id="answers-display" class="chat-container">
                    <h2>连续问答</h2>
                    <div id="file-name">当前询问文件：</div>
                    <div class="chat-content">
                        <!-- 这里可以动态显示问题和匹配的知识 -->
                    </div>
                </div>
                <div id="loading"></div>
            </div>
        </div>
        <div class="input-group mb-3 fixed-bottom">
            <input type="text" id="psword-input" class="form-control" placeholder="请输入您的文件唯一码" list="fileNames">
            <div class="input-group-append">
                <button id="submit-psword" class="btn btn-primary">查询</button>
            </div>
            <input type="text" id="question-input" class="form-control" placeholder="请输入您的问题">
            <input type="number" id="num-similar-input" class="form-control" placeholder="切片数（推荐2）" min="1" max="5" style="width: 150px;">
            <div class="input-group-append">
                <button id="submit-question" class="btn btn-primary">提问</button>
            </div>
        </div>
    </section>
</div>
<!-- ... 其他HTML代码 ... -->



                            
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center">
        <p>&copy; Ask, Seek, Know --- ASK</p>
    </footer>
    <!-- Bootstrap JS, Popper.js, and jQuery -->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script>
// 假设一个全局变量来存储文件代码
// 点击按钮，获取提问
document.getElementById('submit-question').addEventListener('click', function() {
    window.findStatus = 0;
    var questionInput = document.getElementById('question-input').value;
    var file_code = document.getElementById('psword-input').value;
    var numSimilar = parseInt(document.getElementById('num-similar-input').value) || 2; // 获取切片数，如果未输入则默认为2
    if (questionInput) {
        findSimilarSentences(questionInput, " ", file_code, numSimilar)
            .then(knowledge => {
                displayAnswer(questionInput, knowledge, file_code);
                document.getElementById('question-input').value = '';
            })
            .catch(error => {
                console.error('Error:', error);
                alert('发生错误，请稍后再试。');
            });
    } else {
        alert('请输入一个问题。');
    }
});
function displayAnswer(question, knowledge, file_code) {
    var answersDisplay = document.getElementById('answers-display');
    answersDisplay.innerHTML += `
        <div class="chat-bubble-container user-bubble-container">
            <img src="https://static.vecteezy.com/system/resources/thumbnails/005/129/844/small_2x/profile-user-icon-isolated-on-white-background-eps10-free-vector.jpg" class="avatar-user">
            <div class="chat-bubble user-bubble">${question}</div>
        </div>
    `;
    document.getElementById('loading').innerHTML = `
        <div class="chat-bubble-container bot-bubble-container">
            <img src="https://is1-ssl.mzstatic.com/image/thumb/Purple126/v4/59/4a/e5/594ae583-15c6-d5ff-fe72-eab431bdfa99/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/512x512bb.jpg" class="avatar-bot">
            <div class="chat-bubble bot-bubble">思考中，请稍候...</div>
        </div>
    `;
    $.ajax({
        url: 'http://127.0.0.1:8001/dialog',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({question: question, knowledge: knowledge, file_code: file_code}),
        success: function(response) {
            var answerText = response.text;
            document.getElementById('loading').innerHTML = '';
            displayTypingAnswer(answerText, answersDisplay, knowledge);
            if (response.file_code) {
                file_code = response.file_code;
            }
        },
        error: function(error) {
            console.error('Error:', error);
            alert('发生错误，请稍后再试。');
        }
    });
    answersDisplay.scrollTop = answersDisplay.scrollHeight;
}

function displayTypingAnswer(answerText, answersDisplay, knowledge) {
    var botBubbleContainer = document.createElement('div');
    botBubbleContainer.classList.add('chat-bubble-container', 'bot-bubble-container');

    var botAvatar = document.createElement('img');
    botAvatar.src = "https://is1-ssl.mzstatic.com/image/thumb/Purple126/v4/59/4a/e5/594ae583-15c6-d5ff-fe72-eab431bdfa99/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/512x512bb.jpg";
    botAvatar.classList.add('avatar-bot');

    var botBubble = document.createElement('div');
    botBubble.classList.add('chat-bubble', 'bot-bubble');

    botBubbleContainer.appendChild(botAvatar);
    botBubbleContainer.appendChild(botBubble);
    answersDisplay.appendChild(botBubbleContainer);

    let index = 0;
    let htmlContent = '';
    function type() {
        if (index < answerText.length) {
            htmlContent += answerText.charAt(index);
            botBubble.innerHTML = marked.parse(htmlContent);
            index++;
            setTimeout(type, 50); // 调整此值以控制打字速度
        } else {
            displayKnowledge(knowledge, answersDisplay);
        }
    }
    type();
}

function displayKnowledge(knowledge, answersDisplay) {
    var knowledgeBubbleContainer = document.createElement('div');
    knowledgeBubbleContainer.classList.add('chat-bubble-container', 'bot-bubble-container');

    var knowledgeAvatar = document.createElement('img');
    knowledgeAvatar.src = "https://is1-ssl.mzstatic.com/image/thumb/Purple126/v4/59/4a/e5/594ae583-15c6-d5ff-fe72-eab431bdfa99/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/512x512bb.jpg";
    knowledgeAvatar.classList.add('avatar-bot');

    var knowledgeBubble = document.createElement('div');
    knowledgeBubble.classList.add('chat-bubble', 'bot-bubble');
    knowledgeBubble.innerHTML = `<i>参考的资料：${knowledge}</i>`;

    knowledgeBubbleContainer.appendChild(knowledgeAvatar);
    knowledgeBubbleContainer.appendChild(knowledgeBubble);
    answersDisplay.appendChild(knowledgeBubbleContainer);
}
function findSimilarSentences(question, knowledge, file_code, numSimilar) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: 'http://127.0.0.1:8001/get-sentence-embedding/',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({question: question, knowledge: knowledge, file_code: file_code, numSimilar: numSimilar}),
            success: function(response) {
                console.log('问题上传成功:', response);
                var input_embedding = response.embedding;
                // 第二个 AJAX 调用移到第一个成功回调内部
                $.ajax({
                    url: 'find_similar_sentences.php',
                    type: 'POST',
                    data: {
                        input_embedding: input_embedding,
                        file_code: file_code
                    },
                    success: function(response) {
                        window.findStatus = 1;
                        var data = JSON.parse(response);
                        console.log('Most similar record:', data.most_similar_record);
                        var most_similar_record = data.most_similar_record;
                        resolve(most_similar_record.original_text);
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('Error:', textStatus, errorThrown);
                        reject(new Error('Error in finding similar sentences.'));
                    }
                });
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('Error:', textStatus, errorThrown);
                reject(new Error('Error in getting sentence embedding.'));
            }
        });
    });
}
//传输文件到端点
document.addEventListener('DOMContentLoaded', function() {
    $(document).ready(function() {
        $('#upload-knowledge').click(function() {
            document.getElementById('uploadMessage').innerHTML = '解析并上传中，请耐心等待';
            var formData = new FormData();
            var fileInput = document.getElementById('fileInput');
            var file = fileInput.files[0];
            //console.log(file.name);
            if (!file) {
                alert('请上传文件再点击确认上传！');
                return;
            }
            formData.append('file', file);
            $.ajax({
                url: 'http://127.0.0.1:8001/file/', // 注意修改为你的后端接口地址
                type: 'POST',
                data: formData,
                contentType: false, // 必须设为 false
                processData: false, // 必须设为 false
                success: function(response) {
                    console.log('文件上传成功:', response);
                    $.ajax({
                        url: 'upload_to_db.php',
                        type: 'POST',
                        data: {slice_embeddings:response, file_name:file.name},
                        success: function(uploadResponse) {
                            console.log('数据解析并上传成功:', uploadResponse);
                            document.getElementById('uploadMessage').innerHTML = '<br>数据解析并上传成功<br>' + uploadResponse;
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.error('数据传输失败:', textStatus, errorThrown);
                            document.getElementById('uploadMessage').innerHTML = '<br>数据传输失败<br>' + uploadResponse;
                        }
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('文件上传失败:', textStatus, errorThrown);
                }
            });
            
        });
    });
});

//一键复制
document.getElementById('copy').addEventListener('click', function() {
  var uploadMessage = document.getElementById('uploadMessage');
  var content = uploadMessage.textContent || uploadMessage.innerText;
  var regex = /\$2y\$10\$[0-9a-zA-Z]+(.+[0-9a-zA-Z]+)+/g;
  var match = content.match(regex);

  if (match && match[0]) {
    var contentToCopy = match[0];
    navigator.clipboard.writeText(contentToCopy).then(function() {
      var pswordInput = document.getElementById('psword-input');
      pswordInput.value = contentToCopy;
    }).catch(function(err) {
      console.error('复制操作失败：', err);
    });
  } else {
    console.error('没有找到要复制的文本');
  }
});


// 查询文件名
document.getElementById('submit-psword').addEventListener('click', function() {
    var pswordInput = document.getElementById('psword-input');
        var psword = pswordInput.value;
    if (psword) {
        $.ajax({
            type: 'POST',
            url: 'match_pw_file.php',
            data: { psword: psword },
            success: function(response) {
                document.getElementById('file-name').innerHTML = "当前询问文件：" + response;
            },
            error: function() {
                document.getElementById('file-name').innerHTML = "查询失败，请稍后再试。";
            }
        });
    } else {
        alert('请输入一个文件唯一码。');
    }
});

</script>
</body>
</html>